"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const PREFIX = 'room';
function AuthMiddleware(_options, _app) {
    return async (ctx, next) => {
        const { app, socket, logger, helper } = ctx;
        const id = socket.id;
        const nsp = app.io.of('/');
        const query = socket.handshake.query;
        const { room } = query;
        const rooms = [room];
        const tick = (id, msg) => {
            socket.emit(id, helper.parseMsg('deny', msg));
            // tslint:disable-next-line: no-string-literal
            nsp['adapter'].remoteDisconnect(id, true, (err) => {
                logger.error(err);
            });
        };
        const hasRoom = await app.redis.get(`${PREFIX}:${room}`);
        if (!hasRoom) {
            tick(id, {
                type: '已删除',
                message: '删除，房间已删除.',
            });
            return;
        }
        socket.join(room);
        // tslint:disable-next-line: no-string-literal
        nsp['adapter'].clients(rooms, (_err, clients) => {
            // tslint:disable-next-line: no-string-literal
            nsp['to'](room).emit('online', {
                clients,
                action: '加入',
                target: '参加者',
                message: `用户(${id})已加入.`,
            });
        });
        await next();
        // tslint:disable-next-line: no-string-literal
        nsp['adapter'].clients(rooms, (_err, clients) => {
            // tslint:disable-next-line: no-string-literal
            nsp['to'](room).emit('online', {
                clients,
                action: '离开',
                target: '参加者',
                message: `用户(${id})已离开.`,
            });
        });
    };
}
exports.default = AuthMiddleware;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImF1dGgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUM7QUFJdEIsU0FBd0IsY0FBYyxDQUFDLFFBQWEsRUFBRSxJQUFpQjtJQUNyRSxPQUFPLEtBQUssRUFBRSxHQUFZLEVBQUUsSUFBUyxFQUFFLEVBQUU7UUFDdkMsTUFBTSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQztRQUM1QyxNQUFNLEVBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3JCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO1FBRXJDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUM7UUFDdkIsTUFBTSxLQUFLLEdBQUcsQ0FBRSxJQUFJLENBQUUsQ0FBQztRQUV2QixNQUFNLElBQUksR0FBRyxDQUFDLEVBQU8sRUFBRSxHQUFtQixFQUFFLEVBQUU7WUFDNUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUM5Qyw4Q0FBOEM7WUFDOUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxHQUFRLEVBQUUsRUFBRTtnQkFDckQsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUFHLE1BQU0sR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osSUFBSSxDQUFDLEVBQUUsRUFBRTtnQkFDUCxJQUFJLEVBQUUsS0FBSztnQkFDWCxPQUFPLEVBQUUsV0FBVzthQUNyQixDQUFDLENBQUM7WUFDSCxPQUFPO1NBQ1I7UUFFRCxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRWxCLDhDQUE4QztRQUM5QyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLElBQVMsRUFBRSxPQUFZLEVBQUUsRUFBRTtZQUN4RCw4Q0FBOEM7WUFDOUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzdCLE9BQU87Z0JBQ1AsTUFBTSxFQUFFLElBQUk7Z0JBQ1osTUFBTSxFQUFFLEtBQUs7Z0JBQ2IsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPO2FBQ3pCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUViLDhDQUE4QztRQUM5QyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLElBQVMsRUFBRSxPQUFZLEVBQUUsRUFBRTtZQUN4RCw4Q0FBOEM7WUFDOUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzdCLE9BQU87Z0JBQ1AsTUFBTSxFQUFFLElBQUk7Z0JBQ1osTUFBTSxFQUFFLEtBQUs7Z0JBQ2IsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPO2FBQ3pCLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQXRERCxpQ0FzREMifQ==