"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
class AlipayController extends egg_1.Controller {
    async pay() {
        const { ctx } = this;
        const data = {
            body: 'Iphone6 16G',
            subject: 'Iphone6 16G',
            out_trade_no: new Date().valueOf(),
            total_amount: '88888',
            request_from_url: 'http://127.0.0.1:7001/',
            product_code: 'FAST_INSTANT_TRADE_PAY',
        };
        const url = await ctx.service.alipay.doPay(data);
        this.ctx.redirect(url);
    }
    async alipayReturn() {
        const { ctx } = this;
        let str = '';
        for (const key in ctx.request.query) {
            str += `${key}=${ctx.request.query[key]}&`;
        }
        ctx.body = str;
    }
    async alipayNotify() {
        const { ctx } = this;
        const params = ctx.request.body;
        await ctx.service.alipay.alipayNotify(params);
    }
}
exports.default = AlipayController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxpcGF5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWxpcGF5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsNkJBQWlDO0FBRWpDLE1BQXFCLGdCQUFpQixTQUFRLGdCQUFVO0lBQy9DLEtBQUssQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNyQixNQUFNLElBQUksR0FBRztZQUNYLElBQUksRUFBRSxhQUFhO1lBQ25CLE9BQU8sRUFBRSxhQUFhO1lBQ3RCLFlBQVksRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRTtZQUNsQyxZQUFZLEVBQUUsT0FBTztZQUNyQixnQkFBZ0IsRUFBRSx3QkFBd0I7WUFDMUMsWUFBWSxFQUFFLHdCQUF3QjtTQUN2QyxDQUFDO1FBRUYsTUFBTSxHQUFHLEdBQVEsTUFBTSxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVNLEtBQUssQ0FBQyxZQUFZO1FBQ3ZCLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsSUFBSSxHQUFHLEdBQVcsRUFBRSxDQUFDO1FBQ3JCLEtBQUssTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUU7WUFDbkMsR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7U0FDNUM7UUFDRCxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztJQUNqQixDQUFDO0lBRU0sS0FBSyxDQUFDLFlBQVk7UUFDdkIsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNyQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztRQUNoQyxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNoRCxDQUFDO0NBQ0Y7QUE5QkQsbUNBOEJDIn0=