"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
const JWT = require("jsonwebtoken");
class HomeController extends egg_1.Controller {
    async index() {
        // const { config } = this.app;
        // const data = {
        //   client_id: config.github.client_id,
        //   scope: config.github.scope,
        // };
        // await this.ctx.render('login.html', data);
        const token = JWT.sign({
            id: 1,
            username: 'priase',
        }, 'private.key', { expiresIn: 60 });
        // console.log(token)
        const verify = JWT.verify(token, 'private.key');
        this.ctx.body = verify;
        // decode = JWT.verify(token, options.secret);
        // if (!decode || !decode.userName) {
        //   ctx.throw(401, '没有权限，请登录');
        // }
        // if (Date.now() - decode.expire > 0) {
        //   ctx.throw(401, 'Token已过期');
        // }
        // await this.ctx.render('socket.html');
    }
}
exports.default = HomeController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhvbWUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSw2QkFBaUM7QUFDakMsb0NBQW9DO0FBRXBDLE1BQXFCLGNBQWUsU0FBUSxnQkFBVTtJQUM3QyxLQUFLLENBQUMsS0FBSztRQUNoQiwrQkFBK0I7UUFDL0IsaUJBQWlCO1FBQ2pCLHdDQUF3QztRQUN4QyxnQ0FBZ0M7UUFDaEMsS0FBSztRQUNMLDZDQUE2QztRQUM3QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ3JCLEVBQUUsRUFBRSxDQUFDO1lBQ0wsUUFBUSxFQUFFLFFBQVE7U0FDbkIsRUFBRSxhQUFhLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUVyQyxxQkFBcUI7UUFFckIsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO1FBQ3ZCLDhDQUE4QztRQUM5QyxxQ0FBcUM7UUFDckMsZ0NBQWdDO1FBQ2hDLElBQUk7UUFDSix3Q0FBd0M7UUFDeEMsZ0NBQWdDO1FBQ2hDLElBQUk7UUFDSix3Q0FBd0M7SUFDMUMsQ0FBQztDQUNGO0FBMUJELGlDQTBCQyJ9