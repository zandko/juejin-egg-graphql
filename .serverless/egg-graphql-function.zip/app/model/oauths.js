/* indent size: 2 */

module.exports = app => {
  const DataTypes = app.Sequelize;

  const Model = app.model.define('oauths', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    oauth_type: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    oauth_id: {
      type: DataTypes.STRING(50),
      allowNull: false
    }
  }, {
    tableName: 'oauths'
  });

  Model.associate = function() {

  }

  return Model;
};
