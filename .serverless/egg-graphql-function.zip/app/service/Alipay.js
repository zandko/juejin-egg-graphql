"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
const alipay_sdk_1 = require("alipay-sdk");
const form_1 = require("alipay-sdk/lib/form");
/**
 * Alipay Service
 */
class Alipays extends egg_1.Service {
    constructor(ctx) {
        super(ctx);
        const { appId, privateKey, alipayPublicKey, gateway } = ctx.app.config.alipay;
        this.alipaySdk = new alipay_sdk_1.default({
            privateKey,
            alipayPublicKey,
            appId,
            gateway,
        });
    }
    async doPay(data) {
        const { ctx, alipaySdk } = this;
        const { return_url, notify_url } = ctx.app.config.alipay;
        const data1 = {
            product_code: 'FAST_INSTANT_TRADE_PAY',
            out_trade_no: new Date().valueOf(),
        };
        try {
            const formData = new form_1.default();
            formData.setMethod('get'); // 请求方式
            formData.addField('notify_url', notify_url); // 支付完成后，支付宝主动向我们的服务器发送回调的地址
            formData.addField('return_url', return_url); // 支付完成后，当前页面跳转的地址
            formData.addField('biz_content', Object.assign(Object.assign({}, data), data1)); // 请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递
            return await alipaySdk.exec('alipay.trade.page.pay', {}, {
                formData,
                validateSign: true,
            });
        }
        catch (error) {
            throw error;
        }
    }
    // 验证异步通知的数据是否正确
    async alipayNotify(params) {
        const { ctx } = this;
        if (params.trade_status === 'TRADE_SUCCESS') {
            await ctx.service.redis.lpush('payInfo', params);
        }
    }
    async paymentRedisPubSub() {
        // const { ctx } = this;
        // let num = 0;
        // // tslint:disable-next-line: no-constant-condition
        // while (true) {
        //   const result = await ctx.service.redis.brpop('payInfo');
        //   num++;
        //   // 处理各种事宜
        //   console.log(num, '==============', result);
        // }
    }
}
exports.default = Alipays;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQWxpcGF5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiQWxpcGF5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsNkJBQXVDO0FBQ3ZDLDJDQUFtQztBQUNuQyw4Q0FBaUQ7QUFHakQ7O0dBRUc7QUFDSCxNQUFxQixPQUFRLFNBQVEsYUFBTztJQUUxQyxZQUFZLEdBQVk7UUFDdEIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ1gsTUFBTSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM5RSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksb0JBQVMsQ0FBQztZQUM3QixVQUFVO1lBQ1YsZUFBZTtZQUNmLEtBQUs7WUFDTCxPQUFPO1NBQ1IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBaUI7UUFDbEMsTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDaEMsTUFBTSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFFekQsTUFBTSxLQUFLLEdBQUc7WUFDWixZQUFZLEVBQUUsd0JBQXdCO1lBQ3RDLFlBQVksRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRTtTQUNuQyxDQUFDO1FBRUYsSUFBSTtZQUNGLE1BQU0sUUFBUSxHQUFHLElBQUksY0FBYyxFQUFFLENBQUM7WUFDdEMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFLLE9BQU87WUFDdEMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBRSw0QkFBNEI7WUFDMUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBRSxrQkFBa0I7WUFDaEUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxhQUFhLGtDQUFPLElBQUksR0FBSyxLQUFLLEVBQUcsQ0FBQyxDQUFHLDBDQUEwQztZQUNyRyxPQUFPLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxFQUFFLEVBQUU7Z0JBQ3ZELFFBQVE7Z0JBQ1IsWUFBWSxFQUFFLElBQUk7YUFDbkIsQ0FBQyxDQUFDO1NBQ0o7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLE1BQU0sS0FBSyxDQUFDO1NBQ2I7SUFDSCxDQUFDO0lBRUQsZ0JBQWdCO0lBQ1QsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFXO1FBQ25DLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFckIsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLGVBQWUsRUFBRTtZQUMzQyxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDbEQ7SUFDSCxDQUFDO0lBRU0sS0FBSyxDQUFDLGtCQUFrQjtRQUM3Qix3QkFBd0I7UUFDeEIsZUFBZTtRQUNmLHFEQUFxRDtRQUNyRCxpQkFBaUI7UUFDakIsNkRBQTZEO1FBQzdELFdBQVc7UUFDWCxjQUFjO1FBQ2QsZ0RBQWdEO1FBQ2hELElBQUk7SUFDTixDQUFDO0NBQ0Y7QUF6REQsMEJBeURDIn0=