"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
const Core = require("@alicloud/pop-core");
const qiniu = require("qiniu");
const fs = require("fs");
const path_1 = require("path");
const nodemailer = require("nodemailer");
/**
 * Utils Service
 */
class Utils extends egg_1.Service {
    constructor() {
        super(...arguments);
        this.uploadDir = 'app/public/uploads'; // 上传目录
    }
    /**
     * 发送短信
     * @param {string} PhoneNumbers 手机号
     * @memberof Utils
     */
    sendSms(PhoneNumbers) {
        const { ctx, app } = this;
        const { accessKeyId, accessKeySecret, endpoint, apiVersion, sendSms } = app.config.aliyun;
        const { RegionId, SignName, TemplateCode } = sendSms;
        const client = new Core({
            accessKeyId,
            accessKeySecret,
            endpoint,
            apiVersion,
        });
        const sendCode = ctx.helper.smsCode();
        const params = {
            RegionId,
            PhoneNumbers,
            SignName,
            TemplateCode,
            TemplateParam: JSON.stringify({ code: sendCode }),
        };
        const requestOption = {
            method: 'POST',
        };
        return new Promise(async (resolve, _reject) => {
            await client.request('SendSms', params, requestOption).then(async (result) => {
                await ctx.service.redis.set(PhoneNumbers, sendCode, 60);
                return resolve(result);
            }).catch((ex) => {
                resolve(ex.data);
            });
        });
    }
    /**
     * 上传图片
     * @param file 流
     */
    async processUpload(file) {
        const { _ } = this.ctx.helper;
        const { stream, mimetype, encoding } = file;
        const suffix = _.split(mimetype, '/', 2)[1];
        const { path } = await this.storeUpload(stream, suffix);
        const result = await this.uploader(path, suffix);
        const { key } = result;
        return {
            filename: key,
            mimetype,
            encoding,
        };
    }
    /**
     * 保存图片
     * @param stream   流
     * @param filename 名称
     */
    async storeUpload(stream, suffix) {
        const { ctx, uploadDir } = this;
        const { dayjs, uuidv1 } = ctx.helper;
        const id = uuidv1();
        const dirName = dayjs(Date.now()).format('YYYYMMDD');
        const filename = `${id}.${suffix}`;
        if (!fs.existsSync(path_1.join(uploadDir, dirName)))
            fs.mkdirSync(path_1.join(uploadDir, dirName));
        const path = path_1.join(uploadDir, dirName, filename);
        return new Promise((resolve, reject) => stream.pipe(fs.createWriteStream(path))
            .on('finish', () => resolve({ id, path }))
            .on('error', reject));
    }
    /**
     * 获取七牛云token
     */
    getToken() {
        const { app } = this;
        const { AccessKey: accessKey, SecretKey: secretKey, Bucket } = app.config.qiniu;
        const putPolicy = new qiniu.rs.PutPolicy({ scope: Bucket });
        const mac = new qiniu.auth.digest.Mac(accessKey, secretKey);
        const uploadToken = putPolicy.uploadToken(mac);
        return uploadToken;
    }
    /**
     * 上传图片至七牛
     * @param {string} localFile  图片位置
     * @param {string} suffix     后缀
     */
    uploader(localFile, suffix) {
        const { ctx, app } = this;
        const { Domain } = app.config.qiniu;
        const config = new qiniu.conf.Config();
        config.zone = qiniu.zone.Zone_z0;
        const formUploader = new qiniu.form_up.FormUploader(config);
        const token = this.getToken();
        const putExtra = new qiniu.form_up.PutExtra();
        const key = ctx.helper.uuidv1() + '.' + suffix;
        return new Promise(resolve => {
            formUploader.putFile(token, key, localFile, putExtra, (respErr, respBody, respInfo) => {
                if (respErr) {
                    throw respErr;
                }
                if (respInfo.statusCode === 200) {
                    const { hash, key } = respBody;
                    const result = {
                        hash,
                        key: `${Domain}/${key}`,
                    };
                    resolve(result);
                }
            });
        });
    }
    /**
     * 发送邮件
     * @param data 参数
     */
    async sendMail(data) {
        const { to, subject, html } = data;
        const { host, port, auth } = this.app.config.mail;
        // 创建传输器对象
        const transporter = nodemailer.createTransport({ host, port, auth });
        try {
            // 使用定义的传输对象发送邮件
            return await transporter.sendMail({
                from: auth.user,
                to,
                subject,
                html,
            });
        }
        catch (error) {
            throw error;
        }
    }
}
exports.default = Utils;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJVdGlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDZCQUE4QjtBQUM5QiwyQ0FBMkM7QUFDM0MsK0JBQStCO0FBQy9CLHlCQUF5QjtBQUN6QiwrQkFBNEI7QUFDNUIseUNBQXlDO0FBRXpDOztHQUVHO0FBQ0gsTUFBcUIsS0FBTSxTQUFRLGFBQU87SUFBMUM7O1FBQ1UsY0FBUyxHQUFHLG9CQUFvQixDQUFDLENBQUUsT0FBTztJQW1KcEQsQ0FBQztJQWxKQzs7OztPQUlHO0lBQ0ksT0FBTyxDQUFDLFlBQW9CO1FBQ2pDLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQzFCLE1BQU0sRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDMUYsTUFBTSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLEdBQUcsT0FBTyxDQUFDO1FBRXJELE1BQU0sTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDO1lBQ3RCLFdBQVc7WUFDWCxlQUFlO1lBQ2YsUUFBUTtZQUNSLFVBQVU7U0FDWCxDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBRXRDLE1BQU0sTUFBTSxHQUFHO1lBQ2IsUUFBUTtZQUNSLFlBQVk7WUFDWixRQUFRO1lBQ1IsWUFBWTtZQUNaLGFBQWEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDO1NBQ2xELENBQUM7UUFFRixNQUFNLGFBQWEsR0FBRztZQUNwQixNQUFNLEVBQUUsTUFBTTtTQUNmLENBQUM7UUFFRixPQUFPLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLEVBQUU7WUFDNUMsTUFBTSxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFXLEVBQUUsRUFBRTtnQkFDaEYsTUFBTSxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDeEQsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBTyxFQUFFLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsYUFBYSxDQUFDLElBQVM7UUFDbEMsTUFBTSxFQUFFLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQzlCLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztRQUM1QyxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUMsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDeEQsTUFBTSxNQUFNLEdBQVEsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN0RCxNQUFNLEVBQUUsR0FBRyxFQUFFLEdBQUcsTUFBTSxDQUFDO1FBQ3ZCLE9BQU87WUFDTCxRQUFRLEVBQUUsR0FBRztZQUNiLFFBQVE7WUFDUixRQUFRO1NBQ1QsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFXLEVBQUUsTUFBYztRQUNuRCxNQUFNLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNoQyxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUM7UUFDckMsTUFBTSxFQUFFLEdBQUcsTUFBTSxFQUFFLENBQUM7UUFDcEIsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNyRCxNQUFNLFFBQVEsR0FBRyxHQUFHLEVBQUUsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUNuQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxXQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDckYsTUFBTSxJQUFJLEdBQUcsV0FBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFaEQsT0FBTyxJQUFJLE9BQU8sQ0FBK0IsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FDbkUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDcEMsRUFBRSxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUN6QyxFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUN2QixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ssUUFBUTtRQUNkLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUNoRixNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDNUQsTUFBTSxHQUFHLEdBQUcsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzVELE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFL0MsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxRQUFRLENBQUMsU0FBaUIsRUFBRSxNQUFjO1FBQy9DLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQzFCLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUNwQyxNQUFNLE1BQU0sR0FBUSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDNUMsTUFBTSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUNqQyxNQUFNLFlBQVksR0FBRyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM5QixNQUFNLFFBQVEsR0FBRyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDOUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDO1FBQy9DLE9BQU8sSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDM0IsWUFBWSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxPQUFZLEVBQUUsUUFBYSxFQUFFLFFBQWEsRUFBRSxFQUFFO2dCQUNuRyxJQUFJLE9BQU8sRUFBRTtvQkFDWCxNQUFNLE9BQU8sQ0FBQztpQkFDZjtnQkFDRCxJQUFJLFFBQVEsQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO29CQUMvQixNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLFFBQVEsQ0FBQztvQkFDL0IsTUFBTSxNQUFNLEdBQUc7d0JBQ2IsSUFBSTt3QkFDSixHQUFHLEVBQUUsR0FBRyxNQUFNLElBQUksR0FBRyxFQUFFO3FCQUN4QixDQUFDO29CQUNGLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDakI7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBZTtRQUNuQyxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDbkMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ2xELFVBQVU7UUFDVixNQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsZUFBZSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRXJFLElBQUk7WUFDRixnQkFBZ0I7WUFDaEIsT0FBTyxNQUFNLFdBQVcsQ0FBQyxRQUFRLENBQUM7Z0JBQ2hDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDZixFQUFFO2dCQUNGLE9BQU87Z0JBQ1AsSUFBSTthQUNMLENBQUMsQ0FBQztTQUNKO1FBQUMsT0FBTyxLQUFLLEVBQUU7WUFDZCxNQUFNLEtBQUssQ0FBQztTQUNiO0lBQ0gsQ0FBQztDQUNGO0FBcEpELHdCQW9KQyJ9