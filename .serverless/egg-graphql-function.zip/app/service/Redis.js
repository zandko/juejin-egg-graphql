"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
/**
 * Redis Service
 */
class Redis extends egg_1.Service {
    /**
     * 设置
     * @param {string} key
     * @param {object} value
     * @param {date} seconds
     * @memberof RedisService
     */
    async set(key, value, seconds) {
        const { redis } = this.app;
        value = JSON.stringify(value);
        if (!seconds)
            await redis.set(key, value);
        else
            await redis.set(key, value, 'EX', seconds);
    }
    /**
     * 获取
     * @param {string} key
     */
    async get(key) {
        const { ctx, app } = this;
        const { redis } = app;
        const data = await redis.get(key);
        if (!data)
            return;
        const result = ctx.helper.JSONParse(data);
        return result;
    }
    /**
     * 插入到列表头部
     * @param key
     * @param value
     */
    async lpush(key, value) {
        const { redis } = this.app;
        await redis.lpush(key, JSON.stringify(value));
    }
    /**
     * 移出并获取列表的最后一个元素
     * @param key
     * @param timeout 阻塞时间  0 永久
     */
    async brpop(key) {
        const { ctx, app } = this;
        const data = await app.redis.brpop(key, '1');
        if (!data)
            return;
        return ctx.helper.JSONParse(data[1]);
    }
    /**
     * 清空
     */
    async flushall() {
        const { redis } = this.app;
        redis.flushall();
        return;
    }
}
exports.default = Redis;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVkaXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJSZWRpcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDZCQUE4QjtBQUU5Qjs7R0FFRztBQUNILE1BQXFCLEtBQU0sU0FBUSxhQUFPO0lBQ3hDOzs7Ozs7T0FNRztJQUNJLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBVyxFQUFFLEtBQVUsRUFBRSxPQUFZO1FBQ3BELE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQzNCLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxPQUFPO1lBQUUsTUFBTSxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzs7WUFDckMsTUFBTSxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQVc7UUFDMUIsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDMUIsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQztRQUN0QixNQUFNLElBQUksR0FBRyxNQUFNLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLElBQUk7WUFBRSxPQUFPO1FBQ2xCLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzFDLE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFXLEVBQUUsS0FBVTtRQUN4QyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUMzQixNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBVztRQUM1QixNQUFNLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztRQUMxQixNQUFNLElBQUksR0FBUSxNQUFNLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU87UUFDbEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7O09BRUc7SUFDSSxLQUFLLENBQUMsUUFBUTtRQUNuQixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUMzQixLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakIsT0FBTztJQUNULENBQUM7Q0FDRjtBQTFERCx3QkEwREMifQ==