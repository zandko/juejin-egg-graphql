"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
const sequelize_1 = require("sequelize");
/**
 * User Service
 */
class User extends egg_1.Service {
    constructor(ctx) {
        super(ctx);
        this.database = ctx.model.Users;
    }
    /**
     * 避免 N + 1 的问题
     * @param {Array|number} ids 唯一主键
     */
    fetch(ids) {
        const { ctx } = this;
        const users = this.database.findAll({
            where: {
                id: {
                    [sequelize_1.Op.in]: ids,
                },
            },
            include: {
                model: ctx.model.Oauths,
            },
        }).then((us) => us.map(u => u.toJSON()));
        return users;
    }
    /**
     * 用户列表
     * @param {object} 基础条件
     */
    async fetchAll(params) {
        const { ctx } = this;
        const limit = params && params.limit || 10;
        const offset = params && params.offset || 1;
        const orderBy = params && params.orderBy || 'id';
        const orderType = params && params.orderType || 'DESC';
        const result = await this.database.findAll({
            limit,
            offset: limit * (offset - 1),
            order: [
                [orderBy, orderType],
            ],
            include: {
                model: ctx.model.Oauths,
            },
        });
        return result.map((v) => v.toJSON());
    }
    /**
     * 用户登录
     * @param {string} phone  手机号
     * @param {string} password 密码
     * @memberof User
     */
    async fetchByNamePassword(phone, password) {
        const { ctx } = this;
        const uuid = ctx.helper.uuidv1();
        const user = await this.database.findOne({
            where: {
                phone,
                password,
            },
        });
        if (!user)
            return null;
        const result = JSON.stringify(user);
        await ctx.service.redis.set(uuid, result, 3600 * 24);
        return uuid;
    }
    /**
     * 用户注册
     * @param {object} data 注册信息
     * @memberof User
     */
    async register(data) {
        const { ctx } = this;
        const { code, name, phone, password } = data;
        const r_code = await ctx.service.redis.get(phone);
        if (Number(code) === Number(r_code)) {
            return await this.database.create({ name, phone, password });
        }
    }
    /**
     * GitHub 注册
     * @param {object} data 用户信息
     * @memberof User
     */
    async githubRegister(data) {
        const { login: name, node_id: oauth_id, avatar_url: avatar, oauth_type } = data;
        const user = await this.database.create({ name, avatar });
        if (user) {
            const { id } = user;
            const oauth = {
                user_id: id,
                oauth_id,
                oauth_type,
            };
            return await this.ctx.service.oauth.create(oauth);
        }
    }
}
exports.default = User;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVXNlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIlVzZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSw2QkFBOEI7QUFDOUIseUNBQStCO0FBSS9COztHQUVHO0FBQ0gsTUFBcUIsSUFBSyxTQUFRLGFBQU87SUFFdkMsWUFBWSxHQUFRO1FBQ2xCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNYLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxHQUFRO1FBQ25CLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDbEMsS0FBSyxFQUFFO2dCQUNMLEVBQUUsRUFBRTtvQkFDRixDQUFDLGNBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHO2lCQUNiO2FBQ0Y7WUFDRCxPQUFPLEVBQUU7Z0JBQ1AsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTTthQUN4QjtTQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUE2QyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwRixPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQXlCO1FBQzdDLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLE1BQU0sQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDO1FBQzNDLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQztRQUM1QyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksTUFBTSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUM7UUFDakQsTUFBTSxTQUFTLEdBQUcsTUFBTSxJQUFJLE1BQU0sQ0FBQyxTQUFTLElBQUksTUFBTSxDQUFDO1FBRXZELE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDekMsS0FBSztZQUNMLE1BQU0sRUFBRSxLQUFLLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLEtBQUssRUFBRTtnQkFDTCxDQUFFLE9BQU8sRUFBRSxTQUFTLENBQUU7YUFDdkI7WUFDRCxPQUFPLEVBQUU7Z0JBQ1AsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTTthQUN4QjtTQUNGLENBQUMsQ0FBQztRQUNILE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQTBCLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxLQUFhLEVBQUUsUUFBZ0I7UUFDOUQsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNyQixNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2pDLE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDdkMsS0FBSyxFQUFFO2dCQUNMLEtBQUs7Z0JBQ0wsUUFBUTthQUNUO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUk7WUFBRSxPQUFPLElBQUksQ0FBQztRQUN2QixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BDLE1BQU0sR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQ3JELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLElBQW1CO1FBQ2hDLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztRQUM3QyxNQUFNLE1BQU0sR0FBRyxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbkMsT0FBTyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzlEO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxLQUFLLENBQUMsY0FBYyxDQUFDLElBQVM7UUFDbkMsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNoRixNQUFNLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFFMUQsSUFBSSxJQUFJLEVBQUU7WUFDUixNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLE1BQU0sS0FBSyxHQUFHO2dCQUNaLE9BQU8sRUFBRSxFQUFFO2dCQUNYLFFBQVE7Z0JBQ1IsVUFBVTthQUNYLENBQUM7WUFDRixPQUFPLE1BQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNuRDtJQUNILENBQUM7Q0FDRjtBQXpHRCx1QkF5R0MifQ==