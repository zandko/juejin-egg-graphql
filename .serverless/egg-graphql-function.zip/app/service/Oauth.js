"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
/**
 * Oauth Service
 */
class Oauth extends egg_1.Service {
    constructor(ctx) {
        super(ctx);
        this.database = ctx.model.Oauths;
    }
    /**
     * 添加第三方信息
     * @param {IOauthData} data 第三方信息
     * @memberof Oauth
     */
    async create(data) {
        const { user_id, oauth_id, oauth_type } = data;
        return await this.database.create({
            user_id, oauth_id, oauth_type,
        });
    }
    /**
     * 查询第三方信息
     * @param {number} oauth_id 第三方唯一标识
     */
    async findById(oauth_id) {
        return await this.database.findOne({
            where: {
                oauth_id,
            },
        });
    }
}
exports.default = Oauth;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiT2F1dGguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJPYXV0aC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDZCQUE4QjtBQUc5Qjs7R0FFRztBQUNILE1BQXFCLEtBQU0sU0FBUSxhQUFPO0lBRXhDLFlBQVksR0FBUTtRQUNsQixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDWCxJQUFJLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0lBQ25DLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFnQjtRQUNsQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDL0MsT0FBTyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1lBQ2hDLE9BQU8sRUFBRSxRQUFRLEVBQUUsVUFBVTtTQUM5QixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFnQjtRQUNwQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDakMsS0FBSyxFQUFFO2dCQUNMLFFBQVE7YUFDVDtTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQTlCRCx3QkE4QkMifQ==