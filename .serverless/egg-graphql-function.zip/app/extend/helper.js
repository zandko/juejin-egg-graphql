"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const uuidv1 = require("uuid/v1");
const _ = require("lodash");
const dayjs = require("dayjs");
exports.default = {
    uuidv1,
    _,
    dayjs,
    /**
     * socket.io 数据格式
     * @param action
     * @param payload
     * @param metadata
     */
    parseMsg(action, payload = {}, metadata = {}) {
        const meta = Object.assign({}, {
            timestamp: Date.now(),
        }, metadata);
        return {
            meta,
            data: {
                action,
                payload,
            },
        };
    },
    /**
     *  短信验证码
     */
    smsCode() {
        return Math.random().toFixed(6).slice(-6);
    },
    /**
     * 字符串转对象
     * @param {string} str  JSON字符串
     * @param {object} defaultRusult 默认值
     */
    JSONParse(str, defaultRusult = {}) {
        try {
            return JSON.parse(str);
        }
        catch (e) {
            return defaultRusult;
        }
    },
    /**
     * 成功
     * @param {context} ctx 上下文
     * @param {object} data 数据
     * @param {number} code 状态码
     */
    success(ctx, data, code) {
        const timestamp = (Date.now() / 1000).toString();
        ctx.body = {
            timestamp,
            code,
            data,
        };
        ctx.status = code || 200;
    },
    /**
     * 失败
     * @param {context} ctx     上下文
     * @param {number} code     状态码
     * @param {string} message  错误信息
     */
    fail(ctx, code, message) {
        const timestamp = (Date.now() / 1000).toString();
        ctx.body = {
            timestamp,
            code,
            message,
        };
        ctx.status = code;
    },
    /**
     * 找不到
     * @param {context} ctx 上下文
     * @param {string} msg  错误信息
     */
    notFound(ctx, msg) {
        msg = msg || 'not found';
        ctx.throw(ctx.NOT_FOUND_CODE, msg);
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0Esa0NBQWtDO0FBQ2xDLDRCQUE0QjtBQUM1QiwrQkFBK0I7QUFFL0Isa0JBQWU7SUFDYixNQUFNO0lBQ04sQ0FBQztJQUNELEtBQUs7SUFFTDs7Ozs7T0FLRztJQUNILFFBQVEsQ0FBQyxNQUFjLEVBQUUsT0FBTyxHQUFHLEVBQUUsRUFBRSxRQUFRLEdBQUcsRUFBRTtRQUNsRCxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRTtZQUM3QixTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRTtTQUN0QixFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRWIsT0FBTztZQUNMLElBQUk7WUFDSixJQUFJLEVBQUU7Z0JBQ0osTUFBTTtnQkFDTixPQUFPO2FBQ1I7U0FDRixDQUFDO0lBQ0osQ0FBQztJQUNEOztPQUVHO0lBQ0gsT0FBTztRQUNMLE9BQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBQ0Q7Ozs7T0FJRztJQUNILFNBQVMsQ0FBQyxHQUFXLEVBQUUsZ0JBQXFCLEVBQUU7UUFDNUMsSUFBSTtZQUNGLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN4QjtRQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ1YsT0FBTyxhQUFhLENBQUM7U0FDdEI7SUFDSCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxPQUFPLENBQUMsR0FBWSxFQUFFLElBQVMsRUFBRSxJQUFhO1FBQzVDLE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pELEdBQUcsQ0FBQyxJQUFJLEdBQUc7WUFDVCxTQUFTO1lBQ1QsSUFBSTtZQUNKLElBQUk7U0FDTCxDQUFDO1FBQ0YsR0FBRyxDQUFDLE1BQU0sR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILElBQUksQ0FBQyxHQUFZLEVBQUUsSUFBWSxFQUFFLE9BQVk7UUFDM0MsTUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakQsR0FBRyxDQUFDLElBQUksR0FBRztZQUNULFNBQVM7WUFDVCxJQUFJO1lBQ0osT0FBTztTQUNSLENBQUM7UUFDRixHQUFHLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFFBQVEsQ0FBQyxHQUFZLEVBQUUsR0FBWTtRQUNqQyxHQUFHLEdBQUcsR0FBRyxJQUFJLFdBQVcsQ0FBQztRQUN6QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDckMsQ0FBQztDQUNGLENBQUMifQ==