"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function AuthMiddleware(_options, _app) {
    return async (ctx, next) => {
        if (ctx.app.config.graphql.graphiql) {
            await next();
            return;
        }
        const whitelist = ['login', 'register', 'sendSms', 'githubURL'];
        const body = ctx.request.body;
        if (!whitelist.includes(body.operationName)) {
            const uuid = ctx.request.header.authorization;
            const token = ctx.helper.JSONParse(await ctx.service.redis.get(uuid)) || {};
            const { name } = token;
            if (name) {
                await next();
            }
            else {
                ctx.body = { message: '访问令牌鉴权无效，请重新登陆获取！' };
                ctx.status = 401;
            }
        }
        else {
            await next();
        }
    };
}
exports.default = AuthMiddleware;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImF1dGgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxTQUF3QixjQUFjLENBQUMsUUFBYSxFQUFFLElBQWlCO0lBQ3JFLE9BQU8sS0FBSyxFQUFFLEdBQVksRUFBRSxJQUFTLEVBQUUsRUFBRTtRQUN2QyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUU7WUFDbkMsTUFBTSxJQUFJLEVBQUUsQ0FBQztZQUNiLE9BQU87U0FDUjtRQUNELE1BQU0sU0FBUyxHQUFHLENBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFFLENBQUM7UUFDbEUsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7UUFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQzNDLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztZQUM5QyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUM1RSxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDO1lBQ3ZCLElBQUksSUFBSSxFQUFFO2dCQUNSLE1BQU0sSUFBSSxFQUFFLENBQUM7YUFDZDtpQkFBTTtnQkFDTCxHQUFHLENBQUMsSUFBSSxHQUFHLEVBQUUsT0FBTyxFQUFFLG1CQUFtQixFQUFFLENBQUM7Z0JBQzVDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO2FBQ2xCO1NBQ0Y7YUFBTTtZQUNMLE1BQU0sSUFBSSxFQUFFLENBQUM7U0FDZDtJQUNILENBQUMsQ0FBQztBQUNKLENBQUM7QUF0QkQsaUNBc0JDIn0=