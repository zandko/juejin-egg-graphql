// tslint:disable-next-line: no-var-requires
export default require('koa-json-error');
