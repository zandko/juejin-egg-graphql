"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    Query: {
        async githubURL(_root, {}, { connector }) {
            return await connector.utils.githubURL();
        },
    },
    Mutation: {
        async sendSms(_root, { PhoneNumbers }, { connector }) {
            return await connector.utils.sendSms(PhoneNumbers);
        },
        async singleUpload(_root, { file }, { connector }) {
            return await connector.utils.singleUpload(await file);
        },
        async sendMail(_root, { data }, { connector }) {
            const mail = await connector.utils.sendMail(data);
            return mail.response;
        },
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyZXNvbHZlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGtCQUFlO0lBQ2IsS0FBSyxFQUFFO1FBQ0wsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFVLEVBQUUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFO1lBQzNDLE9BQU8sTUFBTSxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQzNDLENBQUM7S0FDRjtJQUVELFFBQVEsRUFBRTtRQUNSLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBVSxFQUFFLEVBQUUsWUFBWSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUU7WUFDdkQsT0FBTyxNQUFNLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3JELENBQUM7UUFDRCxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFO1lBQ3BELE9BQU8sTUFBTSxTQUFTLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDO1FBQ3hELENBQUM7UUFDRCxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFO1lBQ2hELE1BQU0sSUFBSSxHQUFHLE1BQU0sU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbEQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3ZCLENBQUM7S0FDRjtDQUNGLENBQUMifQ==