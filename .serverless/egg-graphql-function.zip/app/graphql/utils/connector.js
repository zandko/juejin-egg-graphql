"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UtilsConnector {
    constructor(ctx) {
        this.ctx = ctx;
    }
    /**
     * 发送短信
     * @param {string} PhoneNumbers 手机号
     * @memberof UtilsConnector
     */
    async sendSms(PhoneNumbers) {
        const { ctx } = this;
        return await ctx.service.utils.sendSms(PhoneNumbers);
    }
    /**
     * 获取GitHub 登录地址
     */
    githubURL() {
        const { login_url, client_id, scope } = this.ctx.app.config.github;
        return `${login_url}?client_id=${client_id}&scope=${scope}&state=${Date.now()}`;
    }
    /**
     * @summary Qiniu上传
     * @description
     * @router post /uploader
     * @request formData file file
     */
    async singleUpload(file) {
        const { ctx } = this;
        // const { createReadStream } = file
        // console.log(file.createReadStream)
        // console.log(createReadStream);
        // await ctx.service.utils.uploader(file.stream, 'jpg');
        return await ctx.service.utils.processUpload(file);
        // return 'ss'
    }
    async sendMail(data) {
        const { ctx } = this;
        return await ctx.service.utils.sendMail(data);
    }
}
exports.default = UtilsConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29ubmVjdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsTUFBcUIsY0FBYztJQUVqQyxZQUFZLEdBQVk7UUFDdEIsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDakIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQW9CO1FBQ3ZDLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsT0FBTyxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxTQUFTO1FBQ2QsTUFBTSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUNuRSxPQUFPLEdBQUcsU0FBUyxjQUFjLFNBQVMsVUFBVSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUM7SUFDbEYsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFTO1FBQ2pDLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsb0NBQW9DO1FBQ3BDLHFDQUFxQztRQUNyQyxpQ0FBaUM7UUFDakMsd0RBQXdEO1FBRXhELE9BQU8sTUFBTSxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkQsY0FBYztJQUNoQixDQUFDO0lBRU0sS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFlO1FBQ25DLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDckIsT0FBTyxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNoRCxDQUFDO0NBQ0Y7QUE3Q0QsaUNBNkNDIn0=