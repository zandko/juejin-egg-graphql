"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class HelloConnector {
    hellos() {
        return [
            {
                id: 1,
                name: 'Jack',
            },
            {
                id: 2,
                name: 'Lucy',
            },
        ];
    }
}
exports.default = HelloConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29ubmVjdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsTUFBcUIsY0FBYztJQUNqQyxNQUFNO1FBQ0osT0FBTztZQUNMO2dCQUNFLEVBQUUsRUFBRSxDQUFDO2dCQUNMLElBQUksRUFBRSxNQUFNO2FBQ2I7WUFDRDtnQkFDRSxFQUFFLEVBQUUsQ0FBQztnQkFDTCxJQUFJLEVBQUUsTUFBTTthQUNiO1NBQ0YsQ0FBQztJQUNKLENBQUM7Q0FDRjtBQWJELGlDQWFDIn0=