"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    Query: {
        hellos(_root, {}, { connector }) {
            return connector.hello.hellos();
        },
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyZXNvbHZlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGtCQUFlO0lBQ2IsS0FBSyxFQUFFO1FBQ0wsTUFBTSxDQUFDLEtBQVUsRUFBRSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUU7WUFDbEMsT0FBTyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2xDLENBQUM7S0FDRjtDQUNGLENBQUMifQ==