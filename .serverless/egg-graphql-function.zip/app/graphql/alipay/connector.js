"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AlipayConnector {
    constructor(ctx) {
        this.ctx = ctx;
    }
    async pay(data) {
        const { ctx } = this;
        return await ctx.service.alipay.doPay(data);
    }
}
exports.default = AlipayConnector;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29ubmVjdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29ubmVjdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0EsTUFBcUIsZUFBZTtJQUVsQyxZQUFZLEdBQVk7UUFDdEIsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDakIsQ0FBQztJQUVNLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBaUI7UUFDaEMsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztRQUNyQixPQUFPLE1BQU0sR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzlDLENBQUM7Q0FDRjtBQVZELGtDQVVDIn0=