import { GraphQLUpload } from 'graphql-upload';

export default {
  Date: require('./scalars/date'), // eslint-disable-line
  Upload: GraphQLUpload,
};
