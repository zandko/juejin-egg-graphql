"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const graphql_1 = require("graphql");
const language_1 = require("graphql/language");
exports.default = new graphql_1.GraphQLScalarType({
    name: 'Date',
    description: 'Date custom scalar type',
    parseValue(value) {
        return new Date(value);
    },
    serialize(value) {
        return value.getTime();
    },
    parseLiteral(ast) {
        if (ast.kind === language_1.Kind.INT) {
            return parseInt(ast.value, 10);
        }
        return null;
    },
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxQ0FBNEM7QUFDNUMsK0NBQXdDO0FBRXhDLGtCQUFlLElBQUksMkJBQWlCLENBQUM7SUFDbkMsSUFBSSxFQUFFLE1BQU07SUFDWixXQUFXLEVBQUUseUJBQXlCO0lBQ3RDLFVBQVUsQ0FBQyxLQUFLO1FBQ2QsT0FBTyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBQ0QsU0FBUyxDQUFDLEtBQUs7UUFDYixPQUFPLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQ0QsWUFBWSxDQUFDLEdBQUc7UUFDZCxJQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssZUFBSSxDQUFDLEdBQUcsRUFBRTtZQUN6QixPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0NBQ0YsQ0FBQyxDQUFDIn0=