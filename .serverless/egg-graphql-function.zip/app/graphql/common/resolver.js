"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const graphql_upload_1 = require("graphql-upload");
exports.default = {
    Date: require('./scalars/date'),
    Upload: graphql_upload_1.GraphQLUpload,
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyZXNvbHZlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLG1EQUErQztBQUUvQyxrQkFBZTtJQUNiLElBQUksRUFBRSxPQUFPLENBQUMsZ0JBQWdCLENBQUM7SUFDL0IsTUFBTSxFQUFFLDhCQUFhO0NBQ3RCLENBQUMifQ==