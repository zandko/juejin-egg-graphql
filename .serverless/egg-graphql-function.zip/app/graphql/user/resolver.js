"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    Query: {
        async user(_root, { id }, { connector }) {
            return await connector.user.fetchById(id);
        },
        async users(_root, { params }, { connector }) {
            return await connector.user.fetchAll(params);
        },
        async login(_root, { data }, { connector }) {
            const { phone, password } = data;
            return await connector.user.fetchByNamePassword(phone, password);
        },
    },
    Mutation: {
        async register(_root, { data }, { connector }) {
            return await connector.user.register(data);
        },
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyZXNvbHZlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGtCQUFlO0lBQ2IsS0FBSyxFQUFFO1FBQ0wsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFVLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRTtZQUMxQyxPQUFPLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUMsQ0FBQztRQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBVSxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUU7WUFDL0MsT0FBTyxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQy9DLENBQUM7UUFDRCxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFO1lBQzdDLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ2pDLE9BQU8sTUFBTSxTQUFTLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztRQUNuRSxDQUFDO0tBQ0Y7SUFFRCxRQUFRLEVBQUU7UUFDUixLQUFLLENBQUMsUUFBUSxDQUFDLEtBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFO1lBQ2hELE9BQU8sTUFBTSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM3QyxDQUFDO0tBQ0Y7Q0FDRixDQUFDIn0=