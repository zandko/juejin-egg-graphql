"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const plugin = {
    // static: true,
    // nunjucks: {
    //   enable: true,
    //   package: 'egg-view-nunjucks',
    // },
    graphql: {
        enable: true,
        package: '@switchdog/egg-graphql',
    },
    sequelize: {
        enable: true,
        package: 'egg-sequelize',
    },
    cors: {
        enable: true,
        package: 'egg-cors',
    },
    redis: {
        enable: true,
        package: 'egg-redis',
    },
    ejs: {
        enable: true,
        package: 'egg-view-ejs',
    },
    io: {
        enable: true,
        package: 'egg-socket.io',
    },
};
exports.default = plugin;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGx1Z2luLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicGx1Z2luLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsTUFBTSxNQUFNLEdBQWM7SUFDeEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsa0NBQWtDO0lBQ2xDLEtBQUs7SUFDTCxPQUFPLEVBQUU7UUFDUCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSx3QkFBd0I7S0FDbEM7SUFDRCxTQUFTLEVBQUU7UUFDVCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxlQUFlO0tBQ3pCO0lBQ0QsSUFBSSxFQUFFO1FBQ0osTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsVUFBVTtLQUNwQjtJQUNELEtBQUssRUFBRTtRQUNMLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLFdBQVc7S0FDckI7SUFDRCxHQUFHLEVBQUU7UUFDSCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxjQUFjO0tBQ3hCO0lBQ0QsRUFBRSxFQUFFO1FBQ0YsTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsZUFBZTtLQUN6QjtDQUNGLENBQUM7QUFFRixrQkFBZSxNQUFNLENBQUMifQ==