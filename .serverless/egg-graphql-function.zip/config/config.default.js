"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const read = (filename) => {
    return fs.readFileSync(path.resolve(__dirname, filename), 'ascii');
};
exports.default = (appInfo) => {
    const config = {
        env: 'prod',
        rundir: '/tmp',
        logger: {
            dir: '/tmp',
        },
    };
    // override config from framework / plugin
    // use for cookie sign key, should change to your own and keep security
    config.keys = appInfo.name + '_1575514608445_7750';
    config.oauth = {
        match: '/graphql',
    };
    // add your config here
    config.middleware = ['error', 'auth', 'graphql'];
    // graphql
    config.graphql = {
        router: '/graphql',
        // 是否加载到 app 上，默认开启
        app: true,
        // 是否加载到 agent 上，默认关闭
        agent: false,
        // 是否加载开发者工具 graphiql, 默认开启。路由同 router 字段。使用浏览器打开该可见。
        graphiql: true,
        // 是否添加默认的 `Query`、`Mutation` 以及 `Subscription` 定义，默认关闭
        // 开启后可通过 `extend` 的方式将 `Query`、`Mutation` 以及 `Subscription` 定义到各自的文件夹中
        defaultTypeDefsEnabled: false,
        apolloServerOptions: {
            tracing: true,
            debug: true,
            formatError: (error) => {
                return new Error(error.message);
            },
            formatResponse(data, _all) {
                delete data.extensions; // 当加上 tracing: true 返回到前端的会有extensions对象的值 对前端来说这数据没有用 所有可以删除
                return data;
            },
        },
    };
    config.sequelize = {
        dialect: 'mysql',
        host: '47.100.194.4',
        port: 3306,
        database: 'lovelp',
        username: 'root',
        password: 'root',
        timezone: '+08:00',
        define: {
            freezeTableName: false,
            underscored: true,
            timestamps: false,
        },
    };
    config.redis = {
        client: {
            port: 6379,
            host: '47.100.194.4',
            password: '123456',
            db: 0,
        },
    };
    config.io = {
        init: {},
        namespace: {
            '/': {
                connectionMiddleware: ['auth'],
                packetMiddleware: [],
            },
            '/example': {
                connectionMiddleware: ['auth'],
                packetMiddleware: [],
            },
        },
        redis: {
            host: '47.100.194.4',
            port: 6379,
            auth_pass: '123456',
            db: 0,
        },
    };
    // cors
    config.cors = {
        origin: '*',
        allowMethods: 'GET,HEAD,PUT,POST,DELETE,PATCH',
    };
    // csrf
    config.security = {
        csrf: {
            ignore: () => true,
        },
    };
    config.bodyParser = {
        enable: true,
        jsonLimit: '10mb',
    };
    config.github = {
        login_url: 'https://github.com/login/oauth/authorize',
        // github Client ID
        client_id: '52a36545d74a3dbb7e82',
        // github Client Secret
        client_secret: '0631d5af073d397f3223ea31c8f7ed3f361753f4',
        // 此参数表示只获取用户信息
        scope: ['user'],
    };
    config.aliyun = {
        accessKeyId: 'LTAIwPm6KYRHsSZZ',
        accessKeySecret: 'Cx5ct1FNRb6kxjaIIUQrr6SYbJVkMJ',
        endpoint: 'https://dysmsapi.aliyuncs.com',
        apiVersion: '2017-05-25',
        sendSms: {
            RegionId: 'cn-hangzhou',
            SignName: 'sns服务',
            TemplateCode: 'SMS_135033928',
        },
    };
    config.qiniu = {
        AccessKey: 'FgXzSBikhWJdaPbOLF3A8iUmMS6vkVzAYV3uY81v',
        SecretKey: 'vb3rgr4AxEQXYnoEQBLhsjoBuKhJwMlb_TYeTLBx',
        Bucket: 'egg-lottery',
        Domain: 'q1lzhixqp.bkt.clouddn.com',
    };
    config.alipay = {
        appId: '2016091700531963',
        privateKey: read('./keys/app_priv_key.pem'),
        alipayPublicKey: read('./keys/alipay_public_key.pem'),
        gateway: 'https://openapi.alipaydev.com/gateway.do',
        return_url: 'http://127.0.0.1:7001/alipay/alipayReturn',
        notify_url: 'http://requestbin.net/r/13ip1wr1',
    };
    config.mail = {
        host: 'smtp.163.com',
        port: 465,
        auth: {
            user: 'push_over@163.com',
            pass: 'guodamiao0',
        },
    };
    config.view = {
        mapping: {
            '.html': 'ejs',
        },
    };
    // add your special config in here
    const bizConfig = {
        sourceUrl: `https://github.com/eggjs/examples/tree/master/${appInfo.name}`,
    };
    // the return config will combines to EggAppConfig
    return Object.assign(Object.assign({}, config), bizConfig);
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmRlZmF1bHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb25maWcuZGVmYXVsdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUNBLHlCQUF5QjtBQUN6Qiw2QkFBNkI7QUFFN0IsTUFBTSxJQUFJLEdBQUcsQ0FBQyxRQUFnQixFQUFFLEVBQUU7SUFDaEMsT0FBTyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQztBQUVGLGtCQUFlLENBQUMsT0FBbUIsRUFBRSxFQUFFO0lBQ3JDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsR0FBRyxFQUFFLE1BQU07UUFDWCxNQUFNLEVBQUUsTUFBTTtRQUNkLE1BQU0sRUFBRTtZQUNOLEdBQUcsRUFBRSxNQUFNO1NBQ1o7S0FDNEIsQ0FBQztJQUVoQywwQ0FBMEM7SUFDMUMsdUVBQXVFO0lBQ3ZFLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksR0FBRyxxQkFBcUIsQ0FBQztJQUVuRCxNQUFNLENBQUMsS0FBSyxHQUFHO1FBQ2IsS0FBSyxFQUFFLFVBQVU7S0FDbEIsQ0FBQztJQUVGLHVCQUF1QjtJQUN2QixNQUFNLENBQUMsVUFBVSxHQUFHLENBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUUsQ0FBQztJQUVuRCxVQUFVO0lBQ1YsTUFBTSxDQUFDLE9BQU8sR0FBRztRQUNmLE1BQU0sRUFBRSxVQUFVO1FBQ2xCLG1CQUFtQjtRQUNuQixHQUFHLEVBQUUsSUFBSTtRQUNULHFCQUFxQjtRQUNyQixLQUFLLEVBQUUsS0FBSztRQUNaLHFEQUFxRDtRQUNyRCxRQUFRLEVBQUUsSUFBSTtRQUNkLHVEQUF1RDtRQUN2RCx1RUFBdUU7UUFDdkUsc0JBQXNCLEVBQUUsS0FBSztRQUM3QixtQkFBbUIsRUFBRTtZQUNuQixPQUFPLEVBQUUsSUFBSTtZQUNiLEtBQUssRUFBRSxJQUFJO1lBQ1gsV0FBVyxFQUFFLENBQUMsS0FBVSxFQUFFLEVBQUU7Z0JBQzFCLE9BQU8sSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2xDLENBQUM7WUFDRCxjQUFjLENBQUMsSUFBUyxFQUFFLElBQVM7Z0JBQ2pDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLDhEQUE4RDtnQkFDdEYsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDO1NBQ0Y7S0FDRixDQUFDO0lBRUYsTUFBTSxDQUFDLFNBQVMsR0FBRztRQUNqQixPQUFPLEVBQUUsT0FBTztRQUNoQixJQUFJLEVBQUUsY0FBYztRQUNwQixJQUFJLEVBQUUsSUFBSTtRQUNWLFFBQVEsRUFBRSxRQUFRO1FBQ2xCLFFBQVEsRUFBRSxNQUFNO1FBQ2hCLFFBQVEsRUFBRSxNQUFNO1FBQ2hCLFFBQVEsRUFBRSxRQUFRO1FBQ2xCLE1BQU0sRUFBRTtZQUNOLGVBQWUsRUFBRSxLQUFLO1lBQ3RCLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLFVBQVUsRUFBRSxLQUFLO1NBQ2xCO0tBQ0YsQ0FBQztJQUVGLE1BQU0sQ0FBQyxLQUFLLEdBQUc7UUFDYixNQUFNLEVBQUU7WUFDTixJQUFJLEVBQUUsSUFBSTtZQUNWLElBQUksRUFBRSxjQUFjO1lBQ3BCLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLEVBQUUsRUFBRSxDQUFDO1NBQ047S0FDRixDQUFDO0lBRUYsTUFBTSxDQUFDLEVBQUUsR0FBRztRQUNWLElBQUksRUFBRSxFQUFHO1FBQ1QsU0FBUyxFQUFFO1lBQ1QsR0FBRyxFQUFFO2dCQUNILG9CQUFvQixFQUFFLENBQUUsTUFBTSxDQUFFO2dCQUNoQyxnQkFBZ0IsRUFBRSxFQUFFO2FBQ3JCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLG9CQUFvQixFQUFFLENBQUUsTUFBTSxDQUFFO2dCQUNoQyxnQkFBZ0IsRUFBRSxFQUFFO2FBQ3JCO1NBQ0Y7UUFDRCxLQUFLLEVBQUU7WUFDTCxJQUFJLEVBQUUsY0FBYztZQUNwQixJQUFJLEVBQUUsSUFBSTtZQUNWLFNBQVMsRUFBRSxRQUFRO1lBQ25CLEVBQUUsRUFBRSxDQUFDO1NBQ047S0FDRixDQUFDO0lBRUYsT0FBTztJQUNQLE1BQU0sQ0FBQyxJQUFJLEdBQUc7UUFDWixNQUFNLEVBQUUsR0FBRztRQUNYLFlBQVksRUFBRSxnQ0FBZ0M7S0FDL0MsQ0FBQztJQUVGLE9BQU87SUFDUCxNQUFNLENBQUMsUUFBUSxHQUFHO1FBQ2hCLElBQUksRUFBRTtZQUNKLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJO1NBQ25CO0tBQ0YsQ0FBQztJQUVGLE1BQU0sQ0FBQyxVQUFVLEdBQUc7UUFDbEIsTUFBTSxFQUFFLElBQUk7UUFDWixTQUFTLEVBQUUsTUFBTTtLQUNsQixDQUFDO0lBRUYsTUFBTSxDQUFDLE1BQU0sR0FBRztRQUNkLFNBQVMsRUFBRSwwQ0FBMEM7UUFDckQsbUJBQW1CO1FBQ25CLFNBQVMsRUFBRSxzQkFBc0I7UUFDakMsdUJBQXVCO1FBQ3ZCLGFBQWEsRUFBRSwwQ0FBMEM7UUFDekQsZUFBZTtRQUNmLEtBQUssRUFBRSxDQUFFLE1BQU0sQ0FBRTtLQUNsQixDQUFDO0lBRUYsTUFBTSxDQUFDLE1BQU0sR0FBRztRQUNkLFdBQVcsRUFBRSxrQkFBa0I7UUFDL0IsZUFBZSxFQUFFLGdDQUFnQztRQUNqRCxRQUFRLEVBQUUsK0JBQStCO1FBQ3pDLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLE9BQU8sRUFBRTtZQUNQLFFBQVEsRUFBRSxhQUFhO1lBQ3ZCLFFBQVEsRUFBRSxPQUFPO1lBQ2pCLFlBQVksRUFBRSxlQUFlO1NBQzlCO0tBQ0YsQ0FBQztJQUVGLE1BQU0sQ0FBQyxLQUFLLEdBQUc7UUFDYixTQUFTLEVBQUUsMENBQTBDO1FBQ3JELFNBQVMsRUFBRSwwQ0FBMEM7UUFDckQsTUFBTSxFQUFFLGFBQWE7UUFDckIsTUFBTSxFQUFFLDJCQUEyQjtLQUNwQyxDQUFDO0lBRUYsTUFBTSxDQUFDLE1BQU0sR0FBRztRQUNkLEtBQUssRUFBRSxrQkFBa0I7UUFDekIsVUFBVSxFQUFFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztRQUMzQyxlQUFlLEVBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDO1FBQ3RELE9BQU8sRUFBRSwwQ0FBMEM7UUFDbkQsVUFBVSxFQUFFLDJDQUEyQztRQUN2RCxVQUFVLEVBQUUsa0NBQWtDO0tBQy9DLENBQUM7SUFFRixNQUFNLENBQUMsSUFBSSxHQUFHO1FBQ1osSUFBSSxFQUFFLGNBQWM7UUFDcEIsSUFBSSxFQUFFLEdBQUc7UUFDVCxJQUFJLEVBQUU7WUFDSixJQUFJLEVBQUUsbUJBQW1CO1lBQ3pCLElBQUksRUFBRSxZQUFZO1NBQ25CO0tBQ0YsQ0FBQztJQUVGLE1BQU0sQ0FBQyxJQUFJLEdBQUc7UUFDWixPQUFPLEVBQUU7WUFDUCxPQUFPLEVBQUUsS0FBSztTQUNmO0tBQ0YsQ0FBQztJQUVGLGtDQUFrQztJQUNsQyxNQUFNLFNBQVMsR0FBRztRQUNoQixTQUFTLEVBQUUsaURBQWlELE9BQU8sQ0FBQyxJQUFJLEVBQUU7S0FDM0UsQ0FBQztJQUVGLGtEQUFrRDtJQUNsRCx1Q0FDSyxNQUFNLEdBQ04sU0FBUyxFQUNaO0FBQ0osQ0FBQyxDQUFDIn0=