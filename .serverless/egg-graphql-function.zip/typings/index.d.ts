import 'egg';

declare module 'egg' {
  // export interface IConnector extends PlainObject {}
  // interface Context {
  //   connector: IConnector;
  // }
}