'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const { INTEGER, STRING  } = Sequelize
    await queryInterface.createTable('oauths', {
      id: {
        type: INTEGER,
        primaryKey: true,
        autoIncrement: true,
        comment: '唯一索引',
      },
      user_id: {
        type: INTEGER,
        allowNull: false,
        comment: '用户ID',
      },
      oauth_type: {
        type: STRING,
        allowNull: false,
        comment: '登录类型',
      },
      oauth_id: {
        type: STRING(50),
        allowNull: false,
        comment: '第三方唯一标识',
      }
    })
  },

  down: async queryInterface => {
    await queryInterface.dropTable('oauths');
}
};
